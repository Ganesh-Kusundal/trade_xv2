"""BaseWireAdapter helpers — decimal, datetime, enum_value."""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum

import pytest

from domain.commands import PlaceOrderCommand
from domain.enums import OrderSide, OrderType, TimeInForce
from domain.value_objects import CorrelationId, InstrumentId, Price, Quantity
from plugins.brokers.common.wire import BaseWireAdapter
from plugins.brokers.dhan.wire import DhanWire
from plugins.brokers.upstox.wire import UpstoxWire


class _Color(Enum):
    RED = "red"


def test_to_decimal_from_str_int_float() -> None:
    assert BaseWireAdapter.to_decimal("12.50") == Decimal("12.50")
    assert BaseWireAdapter.to_decimal(7) == Decimal("7")
    assert BaseWireAdapter.to_decimal(Decimal("1.5")) == Decimal("1.5")


def test_to_datetime_from_iso_and_datetime() -> None:
    raw = "2024-01-15T10:30:00+00:00"
    dt = BaseWireAdapter.to_datetime(raw)
    assert isinstance(dt, datetime)
    assert dt.year == 2024
    assert dt.month == 1
    assert dt.tzinfo is not None

    already = datetime(2024, 1, 15, 10, 30, tzinfo=timezone.utc)
    assert BaseWireAdapter.to_datetime(already) is already


def test_enum_value() -> None:
    assert BaseWireAdapter.enum_value(OrderSide.BUY) == "BUY"
    assert BaseWireAdapter.enum_value(_Color.RED) == "red"
    assert BaseWireAdapter.enum_value("plain") == "plain"


def test_dhan_security_id_before_load() -> None:
    wire = DhanWire()
    with pytest.raises(KeyError, match="no Dhan securityId"):
        wire.security_id(InstrumentId(value="NSE:RELIANCE"))


def test_dhan_security_id_raw_digit() -> None:
    wire = DhanWire()
    assert wire.security_id(InstrumentId(value="2885")) == "2885"


def test_dhan_register_and_lookup() -> None:
    wire = DhanWire()
    wire.register_security(InstrumentId(value="NSE:RELIANCE"), "2885")
    assert wire.security_id(InstrumentId(value="NSE:RELIANCE")) == "2885"


def test_upstox_instrument_key_before_load() -> None:
    wire = UpstoxWire()
    with pytest.raises(KeyError, match="no Upstox instrument_key"):
        wire.instrument_key(InstrumentId(value="NSE:RELIANCE"))


def test_upstox_instrument_key_nse_prefix() -> None:
    wire = UpstoxWire()
    assert wire.instrument_key(InstrumentId(value="NSE_EQ:RELIANCE")) == "NSE_EQ:RELIANCE"


def test_upstox_register_and_lookup() -> None:
    wire = UpstoxWire()
    wire.register_key(InstrumentId(value="NSE:RELIANCE"), "NSE_EQ:RELIANCE")
    assert wire.instrument_key(InstrumentId(value="NSE:RELIANCE")) == "NSE_EQ:RELIANCE"


# ---------------------------------------------------------------------------
# Product type tests
# ---------------------------------------------------------------------------

def _make_command(product_type: str | None = None) -> PlaceOrderCommand:
    return PlaceOrderCommand(
        instrument_id=InstrumentId(value="NSE:RELIANCE"),
        side=OrderSide.BUY,
        order_type=OrderType.MARKET,
        quantity=Quantity(value=Decimal("1")),
        price=None,
        time_in_force=TimeInForce.DAY,
        correlation_id=CorrelationId(value=__import__("uuid").uuid4()),
        product_type=product_type,
    )


def test_dhan_product_type_default() -> None:
    wire = DhanWire()
    wire.register_security(InstrumentId(value="NSE:RELIANCE"), "2885")
    body = wire.from_place_command(_make_command())
    assert body["productType"] == "INTRADAY"


def test_dhan_product_type_custom() -> None:
    wire = DhanWire()
    wire.register_security(InstrumentId(value="NSE:RELIANCE"), "2885")
    body = wire.from_place_command(_make_command(product_type="CNC"))
    assert body["productType"] == "CNC"


def test_upstox_product_type_default() -> None:
    wire = UpstoxWire()
    wire.register_key(InstrumentId(value="NSE:RELIANCE"), "NSE_EQ:RELIANCE")
    body = wire.from_place_command(_make_command())
    assert body["product"] == "I"


def test_upstox_product_type_custom() -> None:
    wire = UpstoxWire()
    wire.register_key(InstrumentId(value="NSE:RELIANCE"), "NSE_EQ:RELIANCE")
    body = wire.from_place_command(_make_command(product_type="D"))
    assert body["product"] == "D"


# ---------------------------------------------------------------------------
# Segment tests
# ---------------------------------------------------------------------------

def test_dhan_segment_nse() -> None:
    assert DhanWire().get_segment(InstrumentId(value="NSE:RELIANCE")) == "NSE_EQ"


def test_dhan_segment_nfo() -> None:
    assert DhanWire().get_segment(InstrumentId(value="NFO:NIFTY")) == "NFO_FO"


def test_dhan_segment_mcx() -> None:
    assert DhanWire().get_segment(InstrumentId(value="MCX:GOLD")) == "MCX_COMM"


def test_dhan_segment_bse() -> None:
    assert DhanWire().get_segment(InstrumentId(value="BSE:RELIANCE")) == "BSE_EQ"


def test_dhan_segment_unknown_defaults_nse() -> None:
    assert DhanWire().get_segment(InstrumentId(value="XYZ:FOO")) == "NSE_EQ"


def test_upstox_segment_nse() -> None:
    assert UpstoxWire().get_segment(InstrumentId(value="NSE:RELIANCE")) == "NSE_EQ"


def test_upstox_segment_nfo() -> None:
    assert UpstoxWire().get_segment(InstrumentId(value="NFO:NIFTY")) == "NFO_FO"


def test_upstox_segment_mcx() -> None:
    assert UpstoxWire().get_segment(InstrumentId(value="MCX:GOLD")) == "MCX_COMM"


def test_upstox_segment_bse() -> None:
    assert UpstoxWire().get_segment(InstrumentId(value="BSE:RELIANCE")) == "BSE_EQ"


def test_upstox_segment_unknown_defaults_nse() -> None:
    assert UpstoxWire().get_segment(InstrumentId(value="XYZ:FOO")) == "NSE_EQ"
