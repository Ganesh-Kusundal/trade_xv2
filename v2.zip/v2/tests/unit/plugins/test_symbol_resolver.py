"""SymbolResolver — InstrumentId ↔ broker symbol bidirectional mapping."""

from __future__ import annotations

import pytest

from domain.value_objects import InstrumentId
from plugins.brokers.common.symbol_resolver import SymbolNotFoundError, SymbolResolver


def test_resolve_known_symbol() -> None:
    resolver = SymbolResolver()
    resolver.add(InstrumentId("NSE:RELIANCE"), "RELIANCE")
    assert resolver.resolve(InstrumentId("NSE:RELIANCE")) == "RELIANCE"


def test_lookup_known_instrument() -> None:
    resolver = SymbolResolver()
    resolver.add(InstrumentId("NSE:RELIANCE"), "RELIANCE")
    assert resolver.lookup("RELIANCE") == InstrumentId("NSE:RELIANCE")


def test_resolve_unknown_raises() -> None:
    resolver = SymbolResolver()
    with pytest.raises(SymbolNotFoundError):
        resolver.resolve(InstrumentId("NSE:UNKNOWN"))


def test_lookup_unknown_raises() -> None:
    resolver = SymbolResolver()
    with pytest.raises(SymbolNotFoundError):
        resolver.lookup("UNKNOWN")


def test_overwrite_mapping() -> None:
    resolver = SymbolResolver()
    resolver.add(InstrumentId("NSE:RELIANCE"), "RELIANCE")
    resolver.add(InstrumentId("NSE:RELIANCE"), "REL")
    assert resolver.resolve(InstrumentId("NSE:RELIANCE")) == "REL"
    assert resolver.lookup("REL") == InstrumentId("NSE:RELIANCE")
