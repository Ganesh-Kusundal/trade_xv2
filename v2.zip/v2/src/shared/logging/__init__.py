"""Logging package."""

from shared.logging.setup import setup_logging

__all__ = ["setup_logging"]
