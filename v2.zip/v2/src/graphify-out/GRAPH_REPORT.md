# Graph Report - src  (2026-07-22)

## Corpus Check
- 144 files · ~21,327 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1231 nodes · 3233 edges · 66 communities (52 shown, 14 thin omitted)
- Extraction: 90% EXTRACTED · 10% INFERRED · 0% AMBIGUOUS · INFERRED: 321 edges (avg confidence: 0.51)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `75deacd9`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Quote|Quote]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_OrderId|OrderId]]
- [[_COMMUNITY_Component|Component]]
- [[_COMMUNITY_InstrumentId|InstrumentId]]
- [[_COMMUNITY_MessageLog|MessageLog]]
- [[_COMMUNITY_BrokerId|BrokerId]]
- [[_COMMUNITY_DhanWire|DhanWire]]
- [[_COMMUNITY_UpstoxWire|UpstoxWire]]
- [[_COMMUNITY_schema.py|schema.py]]
- [[_COMMUNITY_MetricsCollector|MetricsCollector]]
- [[_COMMUNITY_DhanGateway|DhanGateway]]
- [[_COMMUNITY_fee_calculator.py|fee_calculator.py]]
- [[_COMMUNITY_connection.py|connection.py]]
- [[_COMMUNITY_BaseTransport|BaseTransport]]
- [[_COMMUNITY_transport.py|transport.py]]
- [[_COMMUNITY_SymbolResolver|SymbolResolver]]
- [[_COMMUNITY_portfolio.py|portfolio.py]]
- [[_COMMUNITY_DhanConnection|DhanConnection]]
- [[_COMMUNITY_setup.py|setup.py]]
- [[_COMMUNITY_rate_limit.py|rate_limit.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_InstrumentId|InstrumentId]]
- [[_COMMUNITY_PaperGateway|PaperGateway]]
- [[_COMMUNITY_BrokerAdapterPort|BrokerAdapterPort]]
- [[_COMMUNITY_UpstoxWire|UpstoxWire]]
- [[_COMMUNITY_OrderId|OrderId]]
- [[_COMMUNITY_PaperOrdersAdapter|PaperOrdersAdapter]]
- [[_COMMUNITY_source_selection.py|source_selection.py]]
- [[_COMMUNITY_orders.py|orders.py]]
- [[_COMMUNITY_DhanWire|DhanWire]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_execution_target.py|execution_target.py]]
- [[_COMMUNITY_factory.py|factory.py]]
- [[_COMMUNITY_resolve_fill_source|resolve_fill_source]]
- [[_COMMUNITY_IdempotencyGuard|IdempotencyGuard]]
- [[_COMMUNITY_CorrelationId|CorrelationId]]
- [[_COMMUNITY_PaperFillSource|PaperFillSource]]
- [[_COMMUNITY_TradingNode|TradingNode]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_PaperGateway|PaperGateway]]
- [[_COMMUNITY_NSETradingCalendar|NSETradingCalendar]]
- [[_COMMUNITY_Money|Money]]
- [[_COMMUNITY_app.py|app.py]]
- [[_COMMUNITY_server.py|server.py]]
- [[_COMMUNITY_app.py|app.py]]
- [[_COMMUNITY_FillSourcePort|FillSourcePort]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_factory.py|factory.py]]
- [[_COMMUNITY_load_config|load_config]]
- [[_COMMUNITY_TradingNode|TradingNode]]
- [[_COMMUNITY_schema.py|schema.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_DhanConnection|DhanConnection]]
- [[_COMMUNITY__NullTransport|_NullTransport]]
- [[_COMMUNITY_.load_instruments|.load_instruments]]
- [[_COMMUNITY_.get_positions|.get_positions]]
- [[_COMMUNITY_PaperOrdersAdapter|PaperOrdersAdapter]]

## God Nodes (most connected - your core abstractions)
1. `Order` - 96 edges
2. `InstrumentId` - 89 edges
3. `OrderId` - 80 edges
4. `PlaceOrderCommand` - 67 edges
5. `OrderSide` - 52 edges
6. `Position` - 48 edges
7. `Quote` - 48 edges
8. `BaseTransport` - 43 edges
9. `Price` - 38 edges
10. `DhanGateway` - 38 edges

## Surprising Connections (you probably didn't know these)
- `ExecutionEngine` --uses--> `OrderStatus`  [INFERRED]
  application/execution/execution_engine.py → domain/enums.py
- `ExecutionEngine` --uses--> `RiskLevel`  [INFERRED]
  application/execution/execution_engine.py → domain/enums.py
- `_EngineIdempotency` --uses--> `ExecutionEngine`  [INFERRED]
  runtime/factory.py → application/execution/execution_engine.py
- `RuntimeFactory` --uses--> `ExecutionEngine`  [INFERRED]
  runtime/factory.py → application/execution/execution_engine.py
- `_TradingCacheStore` --uses--> `OrderStatus`  [INFERRED]
  application/execution/execution_engine.py → domain/enums.py

## Import Cycles
- None detected.

## Communities (66 total, 14 thin omitted)

### Community 0 - "Quote"
Cohesion: 0.14
Nodes (5): PaperMarketDataAdapter, Paper market data — seeded quotes only., PaperStreamingAdapter, Paper streaming — subscribe list only (no push)., PaperConnection

### Community 1 - "__init__.py"
Cohesion: 0.17
Nodes (26): FillSource implementations — Simulated / Paper / Broker / Replay.  Only the fill, Account, DepthLevel, MarketDepth, Quote, Domain entities — Order FSM + market/portfolio snapshots., Trade, AssetClass (+18 more)

### Community 2 - "OrderId"
Cohesion: 0.07
Nodes (4): BrokerAdapterPort, IdempotencyGuard, Any, RiskEnginePort

### Community 3 - "Component"
Cohesion: 0.07
Nodes (23): ABC, Enum, Exception, Component, ComponentHealth, ComponentState, Any, Component ABC and lifecycle state machine. (+15 more)

### Community 4 - "InstrumentId"
Cohesion: 0.06
Nodes (22): InstrumentId, BaseWireAdapter, Any, datetime, Decimal, Wire helpers — normalize broker-native scalars to domain-safe types., DhanMarketDataAdapter, DhanStreamingAdapter (+14 more)

### Community 5 - "MessageLog"
Cohesion: 0.12
Nodes (12): DeadLetter, MessageBus, MessageBusMetrics, In-process typed MessageBus with metrics and dead-letter queue., Optional async publish — runs sync dispatch in a thread., Subscription, InMemoryMessageLog, MessageLog (+4 more)

### Community 6 - "BrokerId"
Cohesion: 0.16
Nodes (19): BrokerId, Dhan broker plugin — sandbox-capable gateway with injectable transport., register(), Paper broker — in-memory venue, no network I/O., Entry point: tradex.brokers → paper., register(), clear_plugins(), get_plugin() (+11 more)

### Community 7 - "DhanWire"
Cohesion: 0.17
Nodes (10): HttpClient, HttpTransport, Any, RateLimitExceeded, HTTP transport Protocol + rate-limited HttpTransport., HTTP 429 or local bucket exhaustion., stdlib HTTP client — no new dependency required for sync REST., Rate-limited sync HTTP with injectable client + bearer token provider. (+2 more)

### Community 8 - "UpstoxWire"
Cohesion: 0.06
Nodes (32): DataCatalog, _parse_ts(), Any, datetime, Path, File-backed JSONL DataCatalog — Parquet-free Phase 5 store.  ponytail: JSONL per, Minimal bar catalog: write_bars / read_bars / query_bars over JSONL., SQL-like filter alias for read_bars (MCP / research callers). (+24 more)

### Community 9 - "schema.py"
Cohesion: 0.36
Nodes (10): ArgumentParser, Namespace, build_parser(), _cmd_backtest(), _cmd_config_validate(), _cmd_paper(), _cmd_scanner(), _cmd_version() (+2 more)

### Community 10 - "MetricsCollector"
Cohesion: 0.11
Nodes (11): AuditSink, Any, Append-only audit sink (ponytail: in-memory list; swap for durable store later)., Compliance audit log — append only; no delete/mutate of prior records., ComponentHealth, HealthRegistry, Component health tracking., Observability primitives. (+3 more)

### Community 11 - "DhanGateway"
Cohesion: 0.16
Nodes (16): ExecutionEngine, datetime, IdempotencyGuard, RiskManager, ExecutionEngine — single order spine: idempotency → risk → fill → OMS., Orchestrates place path. NEVER calls fill_source when risk denies., Execution package — FillSources + ExecutionEngine (zero-parity spine)., Thin in-memory order book for ExecutionEngine when OMS is not wired. (+8 more)

### Community 12 - "fee_calculator.py"
Cohesion: 0.35
Nodes (7): FeeBreakdown, FeeCalculator, Decimal, _q2(), Indian equity fee calculator — pure Decimal math, no I/O., STT + brokerage + exchange + GST for Indian equities., Domain services public API.

### Community 13 - "connection.py"
Cohesion: 0.07
Nodes (17): BaseTransport, Dhan adapter package exports., DhanInstrumentAdapter, Dhan order placement / cancel / modify / book., DhanPortfolioAdapter, Dhan portfolio — positions / holdings / funds., Upstox instruments adapter., UpstoxInstrumentAdapter (+9 more)

### Community 15 - "transport.py"
Cohesion: 0.29
Nodes (3): Any, RiskCheckResult, Build RiskContext for C2 RiskManager; fakes ignore it.

### Community 16 - "SymbolResolver"
Cohesion: 0.33
Nodes (3): (symbol, exchange) → canonical instrument_id string., SymbolNotFoundError, SymbolResolver

### Community 18 - "DhanConnection"
Cohesion: 0.12
Nodes (18): JwtExpiry, _pad(), Parse JWT ``exp`` without signature verification — mirror src JwtExpiry., Return JWT exp as unix seconds, or -1 if unparseable., _access_token_usable(), _default_refresh(), _is_upstox_otp_rate_limit(), Any (+10 more)

### Community 20 - "rate_limit.py"
Cohesion: 0.13
Nodes (8): _BucketConfig, limiter_from_table(), MultiBucketRateLimiter, RateLimitConfig, Multi-bucket token-bucket rate limiting for broker HTTP., Frozen profile — legacy max_per_second/burst; also accepts rate_per_second/capac, TokenBucketRateLimiter, UpstoxConnection — auth + transport + sub-adapters.

### Community 26 - "InstrumentId"
Cohesion: 0.19
Nodes (6): Upstox adapter package exports., Upstox orders adapter., OnOrder, OnQuote, Upstox streaming adapter — quote + order callbacks., UpstoxStreamingAdapter

### Community 27 - "PaperGateway"
Cohesion: 0.05
Nodes (40): pe_ratio(), basis(), Decimal, Futures basis = futures − spot., ema(), Pure indicators: SMA, EMA, RSI., Wilder RSI; returns one value per bar from index `period` onward., rsi() (+32 more)

### Community 28 - "BrokerAdapterPort"
Cohesion: 0.17
Nodes (13): Risk DTOs — RiskContext snapshot + RiskCheckResult., Snapshot at check time — positions, PnL, rate, margin., RiskCheckResult, RiskContext, Application risk package — pre-trade gate, rules engine, kill switch., RiskCheckResult, RiskManager — pre-trade gate + kill switch; fail closed on exception., RiskCheckResult (+5 more)

### Community 29 - "UpstoxWire"
Cohesion: 0.13
Nodes (10): HttpPost, _coerce_wall_clock(), Path, Process-wide TOTP rate-limit guard — mirror src/infrastructure/auth/totp_cooldow, Broker-side rate limit — enforce full cooldown from now., Raised when TOTP generation is blocked by local or broker cooldown., Shared cooldown tracker for TOTP token generation attempts., TotpCooldownGuard (+2 more)

### Community 30 - "OrderId"
Cohesion: 0.13
Nodes (14): Bar, datetime, Price, Decimal, Quantity, Frozen value objects — Decimal for money/price/qty, UUID for CorrelationId., Nanosecond UTC precision timestamp., TimeFrame (+6 more)

### Community 31 - "PaperOrdersAdapter"
Cohesion: 0.13
Nodes (8): StrategyEngine — register strategies; route bars; emit orders via bus., Message, Clock, EventBusPort, timedelta, Domain ports — Protocols only; no I/O implementations., Strategy, StrategyId

### Community 32 - "source_selection.py"
Cohesion: 0.13
Nodes (6): Position, BrokerSnapshot, PaperConnection — owns in-memory orders, positions, quotes, cash., PaperGateway — thin facade over PaperConnection., PaperWire, Paper wire — domain ↔ domain identity (no venue-native payload).

### Community 33 - "orders.py"
Cohesion: 0.13
Nodes (9): OMS — order/position managers and authoritative TradingCache., PositionManager, PositionManager — projects fills into Position qty/avg/realized_pnl., Authoritative in-memory trading state (orders, positions, quotes)., ponytail: plain dicts; ceiling = single-threaded engine. Upgrade: lock/sharding., TradingCache, TradingContext — runtime handle to cache (and optional bus)., ponytail: cache (+ optional bus) only; managers wired by composition root. (+1 more)

### Community 34 - "DhanWire"
Cohesion: 0.17
Nodes (12): ponytail: plain class (no Component lifecycle until bus wiring needed)., RiskManager, DailyLossRule, OrderRateRule, OrderSizeRule, PositionLimitRule, Decimal, RiskConfig (+4 more)

### Community 36 - "execution_target.py"
Cohesion: 0.13
Nodes (17): Environment, Environment, FakeClock, datetime, timedelta, SystemClock / FakeClock — domain Clock protocol implementations., Deterministic clock for REPLAY / BACKTEST. Call advance() to move time., Wall-clock UTC. Used for PAPER / LIVE. (+9 more)

### Community 37 - "factory.py"
Cohesion: 0.30
Nodes (8): DriftItem, _order_key(), Decimal, Pure reconciliation — no I/O, no bus, no broker imports., Compare local vs broker snapshots → DriftItems. Side-effect free., ReconciliationEngine, Reconciliation use-cases — pure compare; heal applied by ExecutionEngine., DriftSeverity

### Community 38 - "resolve_fill_source"
Cohesion: 0.11
Nodes (12): BrokerFillSource, _corr_key(), _filled_from_command(), PaperFillSource, Any, REPLAY — returns recorded fills keyed by correlation_id., Build a FILLED order at command price (or explicit fill_price)., BACKTEST — immediate fill at command price. No I/O. (+4 more)

### Community 39 - "IdempotencyGuard"
Cohesion: 0.16
Nodes (9): ComponentHealth, LifecycleManager, build_broker_adapter(), Any, Resolve broker_id once and construct the gateway with credentials., _EngineIdempotency, Any, IdempotencyGuard (+1 more)

### Community 40 - "CorrelationId"
Cohesion: 0.44
Nodes (12): OrderSide, RiskLevel, DomainEvent, OrderCancelled, OrderFilled, OrderPlaced, OrderRejected, PositionChanged (+4 more)

### Community 41 - "PaperFillSource"
Cohesion: 0.12
Nodes (5): BrokerOrderAdapter, OrderManager, OrderId, DhanOrdersAdapter, UpstoxOrdersAdapter

### Community 42 - "TradingNode"
Cohesion: 0.12
Nodes (14): OrderManager — orchestrates Order FSM; stores results in TradingCache., BuyAndHold, Any, Minimal buy-and-hold strategy — one BUY on first bar (for tests)., Buys once on the first bar at bar.close (LIMIT)., Strategy application package., CancelOrderCommand, ModifyOrderCommand (+6 more)

### Community 43 - "__init__.py"
Cohesion: 0.09
Nodes (22): BacktestEngine, BacktestResult, LiveTradingEngine, PaperTradingEngine, Any, datetime, Research engines — Replay / Backtest / Paper / Live mode wrappers., PAPER mode wrapper — live data + paper fills; requires a Runtime. (+14 more)

### Community 44 - "PaperGateway"
Cohesion: 0.13
Nodes (3): BrokerCapabilities, PaperGateway, Duck-typed BrokerAdapter surface; no network I/O.

### Community 45 - "NSETradingCalendar"
Cohesion: 0.27
Nodes (6): date, NSETradingCalendar, NSE trading calendar — weekends off; optional holiday set.  ponytail: holiday se, Minimal NSE calendar: Sat/Sun + explicit holidays are non-trading., Entry-point hook for tradex.exchanges — returns calendar surface., register()

### Community 46 - "Money"
Cohesion: 0.14
Nodes (7): Adapt TradingCache to OrderStore without depending on OMS layout., _TradingCacheStore, Build SUBMITTED shell — venue ack without fill confirmation., _submitted_from_command(), InMemoryOrderStore, OrderStore, Order

### Community 47 - "app.py"
Cohesion: 0.29
Nodes (7): create_app(), _health_payload(), HealthApp, _make_fastapi_app(), Any, Health HTTP surface — FastAPI if installed, else stdlib http.server., Minimal stdlib health server (no FastAPI).

### Community 48 - "server.py"
Cohesion: 0.40
Nodes (4): list_tools(), MCPServer, Any, MCP server facade — tool list (health included).

### Community 56 - "factory.py"
Cohesion: 0.36
Nodes (6): Runtime composition root — plugin discovery and wiring., Runtime — frozen composition-root handle., Runtime, boot(), Startup sequence — initialize/start lifecycle; freeze environment., initialize_all → start_all; LIVE authenticate; abort if risk unbound; freeze.

### Community 57 - "load_config"
Cohesion: 0.29
Nodes (10): _deep_merge(), _env_overrides(), load_config(), _load_yaml(), Any, Path, Config loader: defaults → base YAML → profile → TRADEX_* env → overrides., Map TRADEX_* env vars onto AppConfig field paths. (+2 more)

### Community 58 - "TradingNode"
Cohesion: 0.22
Nodes (4): Public tradex package surface., Any, configure → start → stop (+ optional submit)., TradingNode

### Community 59 - "schema.py"
Cohesion: 0.33
Nodes (9): BaseModel, ComponentsConfig, DataConfig, DhanBrokerConfig, LoggingConfig, MessageBusConfig, ObservabilityConfig, AppConfig — declarative trading framework configuration. (+1 more)

### Community 60 - "__init__.py"
Cohesion: 0.21
Nodes (3): Money, PaperPortfolioAdapter, Paper portfolio — positions + cash from connection state.

### Community 61 - "DhanConnection"
Cohesion: 0.12
Nodes (14): _default_http_post(), DhanTokenManager, Any, Dhan TOTP auto-token — probe-before-mint (mirror src token_ensure).  Policy: 1., Resolve access token: store → env → TOTP (never proactive mint)., _TokenRecord, DhanConfig, Dhan connection settings — credentials from env or explicit ctor. (+6 more)

### Community 62 - "_NullTransport"
Cohesion: 0.30
Nodes (3): DhanTokenStore, Path, _token_usable()

### Community 63 - ".load_instruments"
Cohesion: 0.13
Nodes (6): Instrument, DataCatalogPort, Any, PaperInstrumentsAdapter, Paper instruments — in-memory catalog., Any

### Community 64 - ".get_positions"
Cohesion: 0.23
Nodes (8): load_env_file(), load_v2_env(), Path, Load .env.local into os.environ (stdlib — no python-dotenv required)., Parse KEY=VALUE lines into os.environ. Returns path if loaded., Load v2/.env.local (fallback: repo-root .env.local)., _check(), main()

## Knowledge Gaps
- **14 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `InstrumentId` connect `InstrumentId` to `Quote`, `__init__.py`, `OrderId`, `UpstoxWire`, `connection.py`, `BaseTransport`, `portfolio.py`, `InstrumentId`, `BrokerAdapterPort`, `OrderId`, `PaperOrdersAdapter`, `source_selection.py`, `orders.py`, `CorrelationId`, `TradingNode`, `PaperGateway`, `DhanConnection`, `.load_instruments`, `PaperOrdersAdapter`?**
  _High betweenness centrality (0.136) - this node is a cross-community bridge._
- **Why does `Order` connect `Money` to `__init__.py`, `OrderId`, `InstrumentId`, `DhanGateway`, `connection.py`, `BaseTransport`, `transport.py`, `portfolio.py`, `InstrumentId`, `OrderId`, `PaperOrdersAdapter`, `source_selection.py`, `orders.py`, `factory.py`, `resolve_fill_source`, `CorrelationId`, `PaperFillSource`, `TradingNode`, `PaperGateway`, `FillSourcePort`, `DhanConnection`, `PaperOrdersAdapter`?**
  _High betweenness centrality (0.061) - this node is a cross-community bridge._
- **Why does `OrderId` connect `PaperFillSource` to `__init__.py`, `OrderId`, `InstrumentId`, `DhanGateway`, `connection.py`, `BaseTransport`, `portfolio.py`, `InstrumentId`, `OrderId`, `PaperOrdersAdapter`, `source_selection.py`, `orders.py`, `factory.py`, `resolve_fill_source`, `CorrelationId`, `TradingNode`, `PaperGateway`, `Money`, `FillSourcePort`, `DhanConnection`, `PaperOrdersAdapter`?**
  _High betweenness centrality (0.056) - this node is a cross-community bridge._
- **Are the 8 inferred relationships involving `Order` (e.g. with `AssetClass` and `ExchangeId`) actually correct?**
  _`Order` has 8 INFERRED edges - model-reasoned connections that need verification._
- **Are the 3 inferred relationships involving `PlaceOrderCommand` (e.g. with `OrderSide` and `OrderType`) actually correct?**
  _`PlaceOrderCommand` has 3 INFERRED edges - model-reasoned connections that need verification._
- **Are the 34 inferred relationships involving `OrderSide` (e.g. with `OrderManager` and `PositionManager`) actually correct?**
  _`OrderSide` has 34 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Application use-cases layer — OMS, execution, strategy orchestration.`, `Analytics application package — feature pipeline and research engines.`, `Research engines — Replay / Backtest / Paper / Live mode wrappers.` to the rest of the system?**
  _210 weakly-connected nodes found - possible documentation gaps or missing edges._