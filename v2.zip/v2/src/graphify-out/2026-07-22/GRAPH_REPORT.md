# Graph Report - src  (2026-07-22)

## Corpus Check
- 135 files · ~14,297 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1004 nodes · 2553 edges · 65 communities (45 shown, 20 thin omitted)
- Extraction: 89% EXTRACTED · 11% INFERRED · 0% AMBIGUOUS · INFERRED: 275 edges (avg confidence: 0.51)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `75deacd9`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Quote|Quote]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_OrderId|OrderId]]
- [[_COMMUNITY_Component|Component]]
- [[_COMMUNITY_InstrumentId|InstrumentId]]
- [[_COMMUNITY_MessageLog|MessageLog]]
- [[_COMMUNITY_BrokerId|BrokerId]]
- [[_COMMUNITY_DhanWire|DhanWire]]
- [[_COMMUNITY_UpstoxWire|UpstoxWire]]
- [[_COMMUNITY_schema.py|schema.py]]
- [[_COMMUNITY_MetricsCollector|MetricsCollector]]
- [[_COMMUNITY_DhanGateway|DhanGateway]]
- [[_COMMUNITY_fee_calculator.py|fee_calculator.py]]
- [[_COMMUNITY_connection.py|connection.py]]
- [[_COMMUNITY_BaseTransport|BaseTransport]]
- [[_COMMUNITY_transport.py|transport.py]]
- [[_COMMUNITY_SymbolResolver|SymbolResolver]]
- [[_COMMUNITY_portfolio.py|portfolio.py]]
- [[_COMMUNITY_DhanConnection|DhanConnection]]
- [[_COMMUNITY_setup.py|setup.py]]
- [[_COMMUNITY_rate_limit.py|rate_limit.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_InstrumentId|InstrumentId]]
- [[_COMMUNITY_PaperGateway|PaperGateway]]
- [[_COMMUNITY_BrokerAdapterPort|BrokerAdapterPort]]
- [[_COMMUNITY_UpstoxWire|UpstoxWire]]
- [[_COMMUNITY_OrderId|OrderId]]
- [[_COMMUNITY_PaperOrdersAdapter|PaperOrdersAdapter]]
- [[_COMMUNITY_source_selection.py|source_selection.py]]
- [[_COMMUNITY_orders.py|orders.py]]
- [[_COMMUNITY_DhanWire|DhanWire]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_execution_target.py|execution_target.py]]
- [[_COMMUNITY_factory.py|factory.py]]
- [[_COMMUNITY_resolve_fill_source|resolve_fill_source]]
- [[_COMMUNITY_IdempotencyGuard|IdempotencyGuard]]
- [[_COMMUNITY_CorrelationId|CorrelationId]]
- [[_COMMUNITY_PaperFillSource|PaperFillSource]]
- [[_COMMUNITY_TradingNode|TradingNode]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_PaperGateway|PaperGateway]]
- [[_COMMUNITY_NSETradingCalendar|NSETradingCalendar]]
- [[_COMMUNITY_Money|Money]]
- [[_COMMUNITY_app.py|app.py]]
- [[_COMMUNITY_server.py|server.py]]
- [[_COMMUNITY_app.py|app.py]]
- [[_COMMUNITY_FillSourcePort|FillSourcePort]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_factory.py|factory.py]]
- [[_COMMUNITY_load_config|load_config]]
- [[_COMMUNITY_TradingNode|TradingNode]]
- [[_COMMUNITY_schema.py|schema.py]]
- [[_COMMUNITY___init__.py|__init__.py]]
- [[_COMMUNITY_DhanConnection|DhanConnection]]
- [[_COMMUNITY__NullTransport|_NullTransport]]
- [[_COMMUNITY_.load_instruments|.load_instruments]]
- [[_COMMUNITY_.get_positions|.get_positions]]

## God Nodes (most connected - your core abstractions)
1. `Order` - 78 edges
2. `OrderId` - 75 edges
3. `PlaceOrderCommand` - 66 edges
4. `InstrumentId` - 51 edges
5. `OrderSide` - 48 edges
6. `BaseTransport` - 48 edges
7. `Quote` - 43 edges
8. `Position` - 35 edges
9. `OrderStatus` - 33 edges
10. `Account` - 31 edges

## Surprising Connections (you probably didn't know these)
- `ExecutionEngine` --uses--> `OrderStatus`  [INFERRED]
  application/execution/execution_engine.py → domain/enums.py
- `ExecutionEngine` --uses--> `RiskLevel`  [INFERRED]
  application/execution/execution_engine.py → domain/enums.py
- `_EngineIdempotency` --uses--> `ExecutionEngine`  [INFERRED]
  runtime/factory.py → application/execution/execution_engine.py
- `RuntimeFactory` --uses--> `ExecutionEngine`  [INFERRED]
  runtime/factory.py → application/execution/execution_engine.py
- `_TradingCacheStore` --uses--> `OrderStatus`  [INFERRED]
  application/execution/execution_engine.py → domain/enums.py

## Import Cycles
- None detected.

## Communities (65 total, 20 thin omitted)

### Community 0 - "Quote"
Cohesion: 0.10
Nodes (10): Instrument, PaperInstrumentsAdapter, Paper instruments — in-memory catalog., PaperMarketDataAdapter, Paper market data — seeded quotes only., PaperPortfolioAdapter, Paper portfolio — positions + cash from connection state., BrokerSnapshot (+2 more)

### Community 1 - "__init__.py"
Cohesion: 0.28
Nodes (22): OrderManager — orchestrates Order FSM; stores results in TradingCache., CancelOrderCommand, ModifyOrderCommand, Order commands — frozen; PlaceOrderCommand requires correlation_id., Account, Bar, DepthLevel, MarketDepth (+14 more)

### Community 2 - "OrderId"
Cohesion: 0.13
Nodes (3): BrokerAdapterPort, OrderId, KeyError

### Community 3 - "Component"
Cohesion: 0.10
Nodes (17): ABC, ComponentHealth, Exception, Component, ComponentHealth, ComponentState, Any, Component ABC and lifecycle state machine. (+9 more)

### Community 4 - "InstrumentId"
Cohesion: 0.12
Nodes (14): InstrumentId, normalize_quote(), Any, Normalize venue quote dict → domain Quote., BaseWireAdapter, Any, datetime, Decimal (+6 more)

### Community 5 - "MessageLog"
Cohesion: 0.12
Nodes (12): DeadLetter, MessageBus, MessageBusMetrics, In-process typed MessageBus with metrics and dead-letter queue., Optional async publish — runs sync dispatch in a thread., Subscription, InMemoryMessageLog, MessageLog (+4 more)

### Community 6 - "BrokerId"
Cohesion: 0.16
Nodes (19): BrokerId, Dhan broker plugin — sandbox-capable gateway with injectable transport., register(), Paper broker — in-memory venue, no network I/O., Entry point: tradex.brokers → paper., register(), clear_plugins(), get_plugin() (+11 more)

### Community 7 - "DhanWire"
Cohesion: 0.13
Nodes (16): BaseTransport, Any, HTTP transport Protocol — concrete clients live in venue plugins., Dhan adapter package exports., DhanInstrumentAdapter, Dhan instrument master loader., DhanMarketDataAdapter, Dhan market data — quotes via injectable transport. (+8 more)

### Community 8 - "UpstoxWire"
Cohesion: 0.06
Nodes (32): DataCatalog, _parse_ts(), Any, datetime, Path, File-backed JSONL DataCatalog — Parquet-free Phase 5 store.  ponytail: JSONL per, Minimal bar catalog: write_bars / read_bars / query_bars over JSONL., SQL-like filter alias for read_bars (MCP / research callers). (+24 more)

### Community 9 - "schema.py"
Cohesion: 0.36
Nodes (10): ArgumentParser, Namespace, build_parser(), _cmd_backtest(), _cmd_config_validate(), _cmd_paper(), _cmd_scanner(), _cmd_version() (+2 more)

### Community 10 - "MetricsCollector"
Cohesion: 0.11
Nodes (11): AuditSink, Any, Append-only audit sink (ponytail: in-memory list; swap for durable store later)., Compliance audit log — append only; no delete/mutate of prior records., ComponentHealth, HealthRegistry, Component health tracking., Observability primitives. (+3 more)

### Community 11 - "DhanGateway"
Cohesion: 0.17
Nodes (10): ExecutionEngine — single order spine: idempotency → risk → fill → OMS., Execution package — FillSources + ExecutionEngine (zero-parity spine)., InMemoryOrderStore, Thin in-memory order book for ExecutionEngine when OMS is not wired., FillSource, IdempotencyGuard, Any, Injectable protocols — prefer application.oms / application.risk when present. (+2 more)

### Community 12 - "fee_calculator.py"
Cohesion: 0.35
Nodes (7): FeeBreakdown, FeeCalculator, Decimal, _q2(), Indian equity fee calculator — pure Decimal math, no I/O., STT + brokerage + exchange + GST for Indian equities., Domain services public API.

### Community 13 - "connection.py"
Cohesion: 0.09
Nodes (13): Upstox adapter package exports., Any, Upstox instrument loader., UpstoxInstrumentAdapter, Upstox order placement / cancel / modify., UpstoxOrdersAdapter, Any, Upstox portfolio — positions / funds. (+5 more)

### Community 15 - "transport.py"
Cohesion: 0.21
Nodes (6): ExecutionEngine, datetime, RiskCheckResult, Orchestrates place path. NEVER calls fill_source when risk denies., Build RiskContext for C2 RiskManager; fakes ignore it., ComponentId

### Community 16 - "SymbolResolver"
Cohesion: 0.33
Nodes (3): (symbol, exchange) → canonical instrument_id string., SymbolNotFoundError, SymbolResolver

### Community 18 - "DhanConnection"
Cohesion: 0.17
Nodes (6): BrokerOrderAdapter, EventBusPort, IdempotencyGuard, Any, RiskEnginePort, Protocol

### Community 27 - "PaperGateway"
Cohesion: 0.05
Nodes (40): pe_ratio(), basis(), Decimal, Futures basis = futures − spot., ema(), Pure indicators: SMA, EMA, RSI., Wilder RSI; returns one value per bar from index `period` onward., rsi() (+32 more)

### Community 28 - "BrokerAdapterPort"
Cohesion: 0.15
Nodes (19): Risk DTOs — RiskContext snapshot + RiskCheckResult., Snapshot at check time — positions, PnL, rate, margin., RiskCheckResult, RiskContext, Application risk package — pre-trade gate, rules engine, kill switch., RiskManager — pre-trade gate + kill switch; fail closed on exception., ponytail: plain class (no Component lifecycle until bus wiring needed)., RiskManager (+11 more)

### Community 29 - "UpstoxWire"
Cohesion: 0.24
Nodes (4): Upstox market data — quotes via injectable transport., UpstoxMarketDataAdapter, Any, UpstoxWire

### Community 30 - "OrderId"
Cohesion: 0.11
Nodes (9): PositionManager — projects fills into Position qty/avg/realized_pnl., Any, AccountId, Money, Price, Decimal, Quantity, PaperOrdersAdapter (+1 more)

### Community 31 - "PaperOrdersAdapter"
Cohesion: 0.18
Nodes (8): Clock, DataCatalogPort, datetime, timedelta, Domain ports — Protocols only; no I/O implementations., Frozen value objects — Decimal for money/price/qty, UUID for CorrelationId., StrategyId, TimeFrame

### Community 32 - "source_selection.py"
Cohesion: 0.15
Nodes (10): Authoritative in-memory trading state (orders, positions, quotes)., Position, Quote, ExchangeId, Frozen broker capability flags., DhanGateway — thin BrokerAdapter facade over DhanConnection., PaperGateway — thin facade over PaperConnection., PaperWire (+2 more)

### Community 33 - "orders.py"
Cohesion: 0.14
Nodes (7): PositionManager, ponytail: plain dicts; ceiling = single-threaded engine. Upgrade: lock/sharding., TradingCache, _EngineIdempotency, Any, IdempotencyGuard, Adapt IdempotencyGuard → ExecutionEngine (None for NEW, prior for DUPLICATE).

### Community 34 - "DhanWire"
Cohesion: 0.15
Nodes (5): _filled_from_command(), Build a FILLED order at command price (or explicit fill_price)., RiskCheckResult, RiskCheckResult, PlaceOrderCommand

### Community 36 - "execution_target.py"
Cohesion: 0.13
Nodes (17): PaperFillSource, PAPER — delegates to paper gateway when provided; else simulates., Environment, FakeClock, datetime, timedelta, SystemClock / FakeClock — domain Clock protocol implementations., Deterministic clock for REPLAY / BACKTEST. Call advance() to move time. (+9 more)

### Community 37 - "factory.py"
Cohesion: 0.30
Nodes (8): DriftItem, _order_key(), Decimal, Pure reconciliation — no I/O, no bus, no broker imports., Compare local vs broker snapshots → DriftItems. Side-effect free., ReconciliationEngine, Reconciliation use-cases — pure compare; heal applied by ExecutionEngine., DriftSeverity

### Community 38 - "resolve_fill_source"
Cohesion: 0.22
Nodes (5): BrokerFillSource, Any, BACKTEST — immediate fill at command price. No I/O., LIVE — delegates to broker adapter submit/cancel., SimulatedFillSource

### Community 39 - "IdempotencyGuard"
Cohesion: 0.23
Nodes (7): IdempotencyGuard, IdempotencyResult, IdempotencyStatus, Any, In-memory IdempotencyGuard — NEW | DUPLICATE+prior; fail closed on missing id., ponytail: process-local dict; ceiling = single node. Upgrade: Redis/shared store, Idempotency infrastructure — in-memory guard implementing domain port.

### Community 40 - "CorrelationId"
Cohesion: 0.31
Nodes (5): _corr_key(), FillSource implementations — Simulated / Paper / Broker / Replay.  Only the fill, REPLAY — returns recorded fills keyed by correlation_id., ReplayFillSource, CorrelationId

### Community 42 - "TradingNode"
Cohesion: 0.12
Nodes (17): BuyAndHold, Minimal buy-and-hold strategy — one BUY on first bar (for tests)., Buys once on the first bar at bar.close (LIMIT)., Strategy application package., StrategyEngine — register strategies; route bars; emit orders via bus., OrderSide, RiskLevel, DomainEvent (+9 more)

### Community 43 - "__init__.py"
Cohesion: 0.09
Nodes (22): BacktestEngine, BacktestResult, LiveTradingEngine, PaperTradingEngine, Any, datetime, Research engines — Replay / Backtest / Paper / Live mode wrappers., PAPER mode wrapper — live data + paper fills; requires a Runtime. (+14 more)

### Community 44 - "PaperGateway"
Cohesion: 0.13
Nodes (3): BrokerCapabilities, PaperGateway, Duck-typed BrokerAdapter surface; no network I/O.

### Community 45 - "NSETradingCalendar"
Cohesion: 0.27
Nodes (6): date, NSETradingCalendar, NSE trading calendar — weekends off; optional holiday set.  ponytail: holiday se, Minimal NSE calendar: Sat/Sun + explicit holidays are non-trading., Entry-point hook for tradex.exchanges — returns calendar surface., register()

### Community 46 - "Money"
Cohesion: 0.17
Nodes (7): Any, IdempotencyGuard, RiskManager, Adapt TradingCache to OrderStore without depending on OMS layout., _TradingCacheStore, MessageBusPort, OrderStore

### Community 47 - "app.py"
Cohesion: 0.29
Nodes (7): create_app(), _health_payload(), HealthApp, _make_fastapi_app(), Any, Health HTTP surface — FastAPI if installed, else stdlib http.server., Minimal stdlib health server (no FastAPI).

### Community 48 - "server.py"
Cohesion: 0.40
Nodes (4): list_tools(), MCPServer, Any, MCP server facade — tool list (health included).

### Community 56 - "factory.py"
Cohesion: 0.23
Nodes (11): Environment, RuntimeFactory — assemble Runtime from AppConfig (composition root)., RuntimeFactory, Runtime composition root — plugin discovery and wiring., Runtime — frozen composition-root handle., Runtime, boot(), Startup sequence — initialize/start lifecycle; freeze environment. (+3 more)

### Community 57 - "load_config"
Cohesion: 0.36
Nodes (9): _deep_merge(), _env_overrides(), load_config(), _load_yaml(), Any, Path, Config loader: defaults → base YAML → profile → TRADEX_* env → overrides., Map TRADEX_* env vars onto AppConfig field paths. (+1 more)

### Community 58 - "TradingNode"
Cohesion: 0.22
Nodes (4): Public tradex package surface., Any, configure → start → stop (+ optional submit)., TradingNode

### Community 59 - "schema.py"
Cohesion: 0.36
Nodes (8): BaseModel, ComponentsConfig, DataConfig, LoggingConfig, MessageBusConfig, ObservabilityConfig, AppConfig — declarative trading framework configuration., RiskConfig

### Community 60 - "__init__.py"
Cohesion: 0.40
Nodes (4): OMS — order/position managers and authoritative TradingCache., TradingContext — runtime handle to cache (and optional bus)., ponytail: cache (+ optional bus) only; managers wired by composition root., TradingContext

## Knowledge Gaps
- **1 isolated node(s):** `RateLimitConfig`
  These have ≤1 connection - possible missing edges or undocumented components.
- **20 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `InstrumentId` connect `InstrumentId` to `source_selection.py`, `__init__.py`, `orders.py`, `OrderId`, `Quote`, `DhanWire`, `UpstoxWire`, `TradingNode`, `PaperGateway`, `BaseTransport`, `portfolio.py`, `InstrumentId`, `BrokerAdapterPort`, `UpstoxWire`, `OrderId`, `PaperOrdersAdapter`?**
  _High betweenness centrality (0.089) - this node is a cross-community bridge._
- **Why does `PlaceOrderCommand` connect `DhanWire` to `__init__.py`, `OrderId`, `InstrumentId`, `DhanWire`, `DhanGateway`, `connection.py`, `BaseTransport`, `transport.py`, `portfolio.py`, `DhanConnection`, `BrokerAdapterPort`, `UpstoxWire`, `OrderId`, `PaperOrdersAdapter`, `source_selection.py`, `CorrelationId`, `PaperFillSource`, `TradingNode`, `__init__.py`, `PaperGateway`, `FillSourcePort`?**
  _High betweenness centrality (0.087) - this node is a cross-community bridge._
- **Why does `BaseTransport` connect `DhanWire` to `source_selection.py`, `connection.py`, `BaseTransport`, `portfolio.py`, `DhanConnection`, `UpstoxWire`, `InstrumentId`, `DhanConnection`, `_NullTransport`?**
  _High betweenness centrality (0.077) - this node is a cross-community bridge._
- **Are the 8 inferred relationships involving `Order` (e.g. with `AssetClass` and `ExchangeId`) actually correct?**
  _`Order` has 8 INFERRED edges - model-reasoned connections that need verification._
- **Are the 3 inferred relationships involving `PlaceOrderCommand` (e.g. with `OrderSide` and `OrderType`) actually correct?**
  _`PlaceOrderCommand` has 3 INFERRED edges - model-reasoned connections that need verification._
- **Are the 32 inferred relationships involving `OrderSide` (e.g. with `OrderManager` and `PositionManager`) actually correct?**
  _`OrderSide` has 32 INFERRED edges - model-reasoned connections that need verification._
- **What connects `Application use-cases layer — OMS, execution, strategy orchestration.`, `Analytics application package — feature pipeline and research engines.`, `Research engines — Replay / Backtest / Paper / Live mode wrappers.` to the rest of the system?**
  _183 weakly-connected nodes found - possible documentation gaps or missing edges._