"""Dhan streaming — quote + order callbacks over injectable WS."""

from __future__ import annotations

import json
import threading
from collections.abc import Callable
from typing import Any

from domain.entities import Order, Quote
from domain.value_objects import InstrumentId
from plugins.brokers.common.ws_reconnect import ReconnectConfig, WsReconnectManager
from plugins.brokers.dhan.wire import DhanWire

OnQuote = Callable[[Quote], None]
OnOrder = Callable[[Order], None]
WsFactory = Callable[[str], Any]


class DhanStreamingAdapter:
    """ponytail: callback multiplex; real WS factory injected (websockets or test double)."""

    def __init__(
        self,
        *,
        wire: DhanWire,
        ws_url: str = "wss://api-feed.dhan.co",
        token_provider: Callable[[], str] | None = None,
        client_id: str = "",
        ws_factory: WsFactory | None = None,
        reconnect_config: ReconnectConfig | None = None,
    ) -> None:
        self._wire = wire
        self._ws_url = ws_url
        self._token_provider = token_provider or (lambda: "")
        self._client_id = client_id
        self._ws_factory = ws_factory
        self._quote_subs: dict[str, OnQuote | None] = {}
        self._order_cb: OnOrder | None = None
        self._ws: Any | None = None
        self._reconnect_manager = WsReconnectManager(reconnect_config)

    def stream(self, instrument_id: InstrumentId, on_quote: OnQuote | None = None) -> None:
        self._quote_subs[instrument_id.value] = on_quote
        self._ensure_ws()
        if self._ws is not None and hasattr(self._ws, "send"):
            sec = self._wire.security_id(instrument_id)
            segment = self._wire.get_segment(instrument_id)
            self._ws.send(
                json.dumps(
                    {
                        "RequestCode": 15,
                        "InstrumentCount": 1,
                        "InstrumentList": [{"ExchangeSegment": segment, "SecurityId": sec}],
                    }
                )
            )

    def unstream(self, instrument_id: InstrumentId) -> None:
        self._quote_subs.pop(instrument_id.value, None)

    def stream_order(self, on_order: OnOrder | None = None) -> None:
        self._order_cb = on_order
        self._ensure_ws()

    def feed_raw(self, payload: dict[str, Any]) -> None:
        """Test/ingress hook — decode venue payload into callbacks."""
        if "orderId" in payload or payload.get("type") == "order":
            if self._order_cb is not None:
                self._order_cb(self._wire.to_order(payload))
            return
        iid_raw = payload.get("instrument_id") or payload.get("symbol")
        if iid_raw and iid_raw in self._quote_subs:
            cb = self._quote_subs[iid_raw]
            if cb is not None:
                cb(self._wire.to_quote(payload, instrument_id=InstrumentId(value=str(iid_raw))))

    def close(self) -> None:
        if self._ws is not None and hasattr(self._ws, "close"):
            self._ws.close()
        self._ws = None

    def _ensure_ws(self) -> None:
        if self._ws is not None or self._ws_factory is None:
            return
        url = f"{self._ws_url}?version=2&token={self._token_provider()}&clientId={self._client_id}"
        self._ws = self._ws_factory(url)
        self._reconnect_manager.on_connect()

    def _handle_ws_close(self, close_code: int = 0, close_msg: str = "") -> None:
        self._reconnect_manager.on_close()
        self._ws = None
        thread = threading.Thread(target=self._do_reconnect, daemon=True)
        thread.start()

    def _do_reconnect(self) -> None:
        self._reconnect_manager.on_disconnect(
            reconnect_fn=self._ensure_ws,
            replay_fn=self._replay_subscriptions,
        )

    def _replay_subscriptions(self) -> None:
        for instrument_id_str in self._quote_subs:
            self._send_subscribe(InstrumentId(value=instrument_id_str))
        if self._order_cb is not None:
            self._send_order_subscribe()

    def _send_subscribe(self, instrument_id: InstrumentId) -> None:
        if self._ws is not None and hasattr(self._ws, "send"):
            sec = self._wire.security_id(instrument_id)
            segment = self._wire.get_segment(instrument_id)
            self._ws.send(
                json.dumps(
                    {
                        "RequestCode": 15,
                        "InstrumentCount": 1,
                        "InstrumentList": [{"ExchangeSegment": segment, "SecurityId": sec}],
                    }
                )
            )

    def _send_order_subscribe(self) -> None:
        if self._ws is not None and hasattr(self._ws, "send"):
            self._ws.send(
                json.dumps(
                    {
                        "RequestCode": 15,
                        "InstrumentCount": 0,
                        "InstrumentList": [],
                    }
                )
            )
