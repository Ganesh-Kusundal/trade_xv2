"""Dhan instrument master loader + search with CSV caching."""

from __future__ import annotations

import csv
import io
import logging
import os
import time
import urllib.request
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import TYPE_CHECKING, Any

from domain.entities import Instrument
from domain.enums import AssetClass, ExchangeId, InstrumentType, OptionType
from domain.value_objects import InstrumentId
from plugins.brokers.dhan.wire import DhanWire

if TYPE_CHECKING:
    from plugins.brokers.common.transport import BaseTransport

logger = logging.getLogger(__name__)

DHAN_INSTRUMENT_CSV = "https://images.dhan.co/api-data/api/catalog/v1/instruments.csv"
DHAN_MCX_COMM_URL = "https://api.dhan.co/v2/instrument/MCX_COMM"

_RUNTIME_DIR = Path(__file__).resolve().parents[4] / "runtime"

_INSTRUMENT_CACHE_TTL_HOURS = 6.0
_INSTRUMENT_CACHE_CLEANUP_DAYS = 7

_SEGMENT_MAP: dict[tuple[str, str], ExchangeId] = {
    ("NSE", "E"): ExchangeId.NSE,
    ("NSE", "D"): ExchangeId.NSE,
    ("NSE", "I"): ExchangeId.NSE,
    ("BSE", "E"): ExchangeId.BSE,
    ("BSE", "D"): ExchangeId.BSE,
    ("BSE", "I"): ExchangeId.BSE,
    ("MCX", "M"): ExchangeId.MCX,
    ("CDS", "D"): ExchangeId.NSE,
    ("NSE", "C"): ExchangeId.NSE,
    ("BSE", "C"): ExchangeId.BSE,
    ("NSE", "M"): ExchangeId.NSE,
}

_INSTRUMENT_TYPE_MAP: dict[str, InstrumentType] = {
    "EQ": InstrumentType.EQUITY,
    "FUT": InstrumentType.FUTURE,
    "FUTIDX": InstrumentType.FUTURE,
    "FUTSTK": InstrumentType.FUTURE,
    "FUTCOM": InstrumentType.FUTURE,
    "OPT": InstrumentType.OPTION,
    "OPTIDX": InstrumentType.OPTION,
    "OPTSTK": InstrumentType.OPTION,
    "OPTCOM": InstrumentType.OPTION,
    "OPTFUT": InstrumentType.OPTION,
    "ID": InstrumentType.INDEX,
    "BE": InstrumentType.EQUITY,
    "BOND": InstrumentType.EQUITY,
}

_OPTION_TYPE_MAP: dict[str, OptionType] = {
    "CE": OptionType.CALL,
    "PE": OptionType.PUT,
    "CA": OptionType.CALL,
    "PA": OptionType.PUT,
}


class DhanInstrumentAdapter:
    def __init__(self, transport: BaseTransport, wire: DhanWire | None = None) -> None:
        self._transport = transport
        self._wire = wire or DhanWire()
        self._by_id: dict[str, Instrument] = {}

    def load_instruments(self) -> list[Instrument]:
        try:
            return self.load_from_csv()
        except Exception as exc:
            logger.warning("CSV load failed, falling back to REST: %s", exc)
            return self._load_from_rest()

    def _load_from_rest(self) -> list[Instrument]:
        data = self._transport.get("/instrument")
        rows = data if isinstance(data, list) else data.get("data", [])
        out: list[Instrument] = []
        for row in rows:
            inst = self._to_instrument(row)
            self._by_id[inst.instrument_id.value] = inst
            sec = str(row.get("security_id") or row.get("securityId") or "")
            if sec:
                self._wire.register_security(inst.instrument_id, sec)
            out.append(inst)
        return out

    def load_from_csv(self) -> list[Instrument]:
        cache_dir = _RUNTIME_DIR
        cache_dir.mkdir(parents=True, exist_ok=True)

        today = date.today().isoformat()
        cache_path = cache_dir / f"dhan-instruments-{today}.csv"

        self._cleanup_old_cache(cache_dir)

        force_refresh = False
        if cache_path.exists() and cache_path.stat().st_size > 0:
            try:
                mtime = datetime.fromtimestamp(cache_path.stat().st_mtime, tz=timezone.utc)
                cache_age_hours = (datetime.now(timezone.utc) - mtime).total_seconds() / 3600.0
                if cache_age_hours > _INSTRUMENT_CACHE_TTL_HOURS:
                    logger.info("Cache age %.1fh > %.1fh, refreshing", cache_age_hours, _INSTRUMENT_CACHE_TTL_HOURS)
                    force_refresh = True
            except Exception:
                force_refresh = True

        csv_content = None
        if not force_refresh and cache_path.exists() and cache_path.stat().st_size > 0:
            logger.info("Loading instruments from cache: %s", cache_path)
            try:
                csv_content = cache_path.read_text(encoding="utf-8")
            except Exception as exc:
                logger.warning("Failed to read cache: %s", exc)

        if csv_content is None:
            csv_content = self._download_csv(DHAN_INSTRUMENT_CSV)
            tmp_path = cache_path.with_suffix(".csv.tmp")
            tmp_path.write_text(csv_content, encoding="utf-8")
            os.replace(tmp_path, cache_path)

        instruments = self._parse_csv_to_instruments(csv_content)

        mcx_instruments = self._fetch_mcx_supplement()
        if mcx_instruments:
            existing_ids = {i.instrument_id.value for i in instruments}
            added = 0
            for inst in mcx_instruments:
                if inst.instrument_id.value not in existing_ids:
                    instruments.append(inst)
                    self._by_id[inst.instrument_id.value] = inst
                    added += 1
            logger.info("MCX supplement: added %d instruments", added)

        return instruments

    def _download_csv(self, url: str) -> str:
        req = urllib.request.Request(url, headers={"User-Agent": "TradeXV2/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read().decode("utf-8")

    def _parse_csv_to_instruments(self, csv_content: str) -> list[Instrument]:
        reader = csv.DictReader(io.StringIO(csv_content))
        out: list[Instrument] = []
        for row in reader:
            inst = self._csv_row_to_instrument(row)
            if inst is not None:
                self._by_id[inst.instrument_id.value] = inst
                sec = str(row.get("SEM_SMST_SECURITY_ID") or row.get("security_id") or "")
                if sec:
                    self._wire.register_security(inst.instrument_id, sec)
                out.append(inst)
        return out

    def _csv_row_to_instrument(self, row: dict[str, Any]) -> Instrument | None:
        symbol = (row.get("SEM_TRADING_SYMBOL") or row.get("trading_symbol") or "").strip()
        if not symbol:
            return None

        exch_id = (row.get("SEM_EXM_EXCH_ID") or row.get("exchange") or "NSE").strip().upper()
        segment = (row.get("SEM_SEGMENT") or row.get("segment") or "E").strip().upper()

        exchange = _SEGMENT_MAP.get((exch_id, segment))
        if exchange is None:
            exchange = ExchangeId.NSE if "NSE" in exch_id else ExchangeId.BSE if "BSE" in exch_id else ExchangeId.NSE

        inst_name = (row.get("SEM_INSTRUMENT_NAME") or row.get("instrument") or "").strip().upper()
        instrument_type = _INSTRUMENT_TYPE_MAP.get(inst_name, InstrumentType.EQUITY)

        asset_class = AssetClass.EQUITY
        if exchange == ExchangeId.MCX:
            asset_class = AssetClass.COMMODITY
        elif instrument_type in (InstrumentType.FUTURE, InstrumentType.OPTION):
            asset_class = AssetClass.DERIVATIVE

        lot_size = _safe_float(row.get("SEM_LOT_UNITS") or row.get("lot_size"), 1)
        tick_size = _safe_float(row.get("SEM_TICK_SIZE") or row.get("tick_size"), 0.05)
        expiry_str = (row.get("SEM_EXPIRY_DATE") or row.get("expiry_date") or "").strip() or None
        strike_str = (row.get("SEM_STRIKE_PRICE") or row.get("strike_price") or "").strip() or None
        option_type_str = (row.get("SEM_OPTION_TYPE") or row.get("option_type") or "").strip().upper()

        expiry = None
        if expiry_str:
            try:
                expiry = datetime.strptime(expiry_str.split()[0], "%Y-%m-%d")
            except (ValueError, TypeError):
                pass

        strike = None
        if strike_str:
            try:
                strike = Decimal(strike_str)
            except (ValueError, TypeError):
                pass

        option_type = _OPTION_TYPE_MAP.get(option_type_str) if option_type_str and option_type_str != "XX" else None

        iid = InstrumentId(value=f"{exchange.value}:{symbol}")
        return Instrument(
            instrument_id=iid,
            symbol=symbol,
            exchange=exchange,
            asset_class=asset_class,
            currency="INR",
            instrument_type=instrument_type,
            strike=strike,
            expiry=expiry,
            option_type=option_type,
        )

    def _fetch_mcx_supplement(self) -> list[Instrument]:
        try:
            csv_content = self._download_csv(DHAN_MCX_COMM_URL)
        except Exception as exc:
            logger.warning("MCX supplement fetch failed (non-fatal): %s", exc)
            return []

        reader = csv.DictReader(io.StringIO(csv_content))
        out: list[Instrument] = []
        for row in reader:
            segment = (row.get("SEGMENT") or "").strip().upper()
            if segment != "M":
                continue
            inst = self._mcx_row_to_instrument(row)
            if inst is not None:
                out.append(inst)
        return out

    def _mcx_row_to_instrument(self, row: dict[str, Any]) -> Instrument | None:
        symbol_name = (row.get("SYMBOL_NAME") or "").strip().upper()
        instrument = (row.get("INSTRUMENT") or "").strip().upper()
        expiry_str = (row.get("SM_EXPIRY_DATE") or "").strip()
        strike_str = (row.get("STRIKE_PRICE") or "").strip()
        option_type_str = (row.get("OPTION_TYPE") or "").strip().upper()
        security_id = (row.get("SECURITY_ID") or "").strip()
        display_name = (row.get("DISPLAY_NAME") or "").strip()

        trading_symbol = symbol_name
        if expiry_str:
            try:
                dt_str = expiry_str.split()[0]
                dt = datetime.strptime(dt_str, "%Y-%m-%d")
                dd_mmm_yyyy = dt.strftime("%d%b%Y")
                if "FUT" in instrument and "OPT" not in instrument:
                    trading_symbol = f"{symbol_name}-{dd_mmm_yyyy}-FUT"
                elif "OPT" in instrument:
                    try:
                        st = float(strike_str)
                        st_str = str(int(st)) if st % 1 == 0 else str(st)
                    except (ValueError, TypeError):
                        st_str = strike_str
                    opt = "CE" if option_type_str in ("CE", "CA") else "PE" if option_type_str in ("PE", "PA") else ""
                    trading_symbol = f"{symbol_name}-{dd_mmm_yyyy}-{st_str}-{opt}" if opt else f"{symbol_name}-{dd_mmm_yyyy}-{st_str}"
            except Exception:
                pass

        expiry = None
        if expiry_str:
            try:
                expiry = datetime.strptime(expiry_str.split()[0], "%Y-%m-%d")
            except (ValueError, TypeError):
                pass

        strike = None
        if strike_str:
            try:
                strike = Decimal(strike_str)
            except (ValueError, TypeError):
                pass

        option_type = None
        if option_type_str in ("CE", "CA"):
            option_type = OptionType.CALL
        elif option_type_str in ("PE", "PA"):
            option_type = OptionType.PUT

        instrument_type = InstrumentType.FUTURE
        if "OPT" in instrument:
            instrument_type = InstrumentType.OPTION

        lot_size = _safe_float(row.get("LOT_SIZE"), 1)
        tick_size = _safe_float(row.get("TICK_SIZE"), 0.05)

        iid = InstrumentId(value=f"MCX:{trading_symbol}")
        inst = Instrument(
            instrument_id=iid,
            symbol=trading_symbol,
            exchange=ExchangeId.MCX,
            asset_class=AssetClass.COMMODITY,
            currency="INR",
            instrument_type=instrument_type,
            strike=strike,
            expiry=expiry,
            option_type=option_type,
        )
        if security_id:
            self._wire.register_security(iid, security_id)
        return inst

    def search(self, query: str) -> list[Instrument]:
        q = query.upper()
        return [i for i in self._by_id.values() if q in i.symbol.upper() or q in i.instrument_id.value.upper()]

    def resolve(self, instrument_id: InstrumentId) -> Instrument | None:
        return self._by_id.get(instrument_id.value)

    def _to_instrument(self, row: dict[str, Any]) -> Instrument:
        symbol = str(row.get("trading_symbol") or row.get("symbol") or row.get("SEM_TRADING_SYMBOL") or "")
        exch = str(row.get("exchange") or row.get("SEM_EXM_EXCH_ID") or "NSE").upper()
        exchange = ExchangeId.NSE if "NSE" in exch else ExchangeId.BSE if "BSE" in exch else ExchangeId.NSE
        iid = InstrumentId(value=f"{exchange.name}:{symbol}" if symbol else str(row.get("security_id", "")))
        return Instrument(
            instrument_id=iid,
            symbol=symbol or iid.value,
            exchange=exchange,
            asset_class=AssetClass.EQUITY,
            currency="INR",
            instrument_type=InstrumentType.EQUITY,
            strike=Decimal(str(row["strike"])) if row.get("strike") else None,
        )

    def _cleanup_old_cache(self, cache_dir: Path) -> None:
        now = time.time()
        cutoff = now - (_INSTRUMENT_CACHE_CLEANUP_DAYS * 24 * 3600)
        try:
            for path in cache_dir.glob("dhan-instruments-*.csv"):
                if path.is_file() and path.stat().st_mtime < cutoff:
                    path.unlink(missing_ok=True)
        except Exception as exc:
            logger.warning("Cache cleanup failed: %s", exc)


def _safe_float(val: Any, default: float) -> float:
    if val is None or val == "":
        return default
    try:
        return float(val)
    except (TypeError, ValueError):
        return default
