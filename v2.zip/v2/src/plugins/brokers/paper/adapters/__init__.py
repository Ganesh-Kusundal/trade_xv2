"""Paper sub-adapters package."""
