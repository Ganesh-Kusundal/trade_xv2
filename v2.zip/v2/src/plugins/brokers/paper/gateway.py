"""PaperGateway — thin facade over PaperConnection."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from domain.commands import PlaceOrderCommand
from domain.entities import Account, MarketDepth, Order, Position, Quote
from domain.ports.types import BrokerSnapshot
from domain.value_objects import InstrumentId, Money, OrderId, Price
from plugins.brokers.common.capabilities import BrokerCapabilities
from plugins.brokers.paper.connection import PaperConnection

PAPER_CAPABILITIES = BrokerCapabilities(
    supports_market_order=True,
    supports_limit_order=True,
    supports_stop_order=False,
    supports_modify=True,
    supports_cancel=True,
)


class PaperGateway:
    """Duck-typed BrokerAdapter surface; no network I/O."""

    def __init__(
        self,
        starting_cash: Money | None = None,
        auto_fill: bool = True,
    ) -> None:
        self.connection = PaperConnection(starting_cash=starting_cash, auto_fill=auto_fill)
        self.connection.connect()

    def connect(self) -> None:
        """Connect to paper broker (delegates to connection)."""
        if self.connection.is_connected:
            return
        self.connection.connect()

    def close(self) -> None:
        self.connection.close()

    def get_quote(self, instrument_id: InstrumentId) -> Quote:
        return self.connection.market_data.get_quote(instrument_id)

    def set_quote(self, instrument_id: InstrumentId, bid: Decimal, ask: Decimal) -> None:
        self.connection.set_quote(instrument_id, bid, ask)

    def get_ltp(self, instrument_id: InstrumentId) -> Price:
        return self.connection.market_data.get_ltp(instrument_id)

    def get_depth(self, instrument_id: InstrumentId) -> MarketDepth:
        return self.connection.market_data.get_depth(instrument_id)

    def get_history(
        self, instrument_id: InstrumentId, start: datetime, end: datetime
    ) -> list:
        return self.connection.market_data.get_history(instrument_id, start, end)

    def place_order(self, command: PlaceOrderCommand) -> OrderId:
        return self.connection.orders_adapter.place_order(command)

    def submit_order(self, command: PlaceOrderCommand) -> OrderId:
        return self.place_order(command)

    def cancel_order(self, order_id: OrderId) -> None:
        self.connection.orders_adapter.cancel_order(order_id)

    def get_order(self, order_id: OrderId) -> Order:
        return self.connection.orders_adapter.get_order(order_id)

    def get_orderbook(self) -> list[Order]:
        return self.connection.orders_adapter.get_orderbook()

    def get_positions(self) -> list[Position]:
        return self.connection.portfolio.get_positions()

    def get_funds(self) -> Account:
        return self.connection.portfolio.get_funds()

    def mass_status(self) -> BrokerSnapshot:
        return self.connection.mass_status()

    def capabilities(self) -> BrokerCapabilities:
        return PAPER_CAPABILITIES

    def modify_order(self, order_id: OrderId, command: PlaceOrderCommand) -> None:
        self.connection.orders_adapter.modify_order(order_id, command)
