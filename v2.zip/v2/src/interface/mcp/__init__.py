"""MCP package."""
