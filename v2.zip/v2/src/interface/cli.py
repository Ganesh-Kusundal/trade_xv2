"""Interface CLI — commands organized by research questions."""

from __future__ import annotations

import argparse
import sys
from typing import Sequence


def _cmd_version(_args: argparse.Namespace) -> int:
    print("tradex 0.1.0")
    return 0


def _cmd_replay(_args: argparse.Namespace) -> int:
    print("replay (stub)")
    return 0


def _cmd_backtest(_args: argparse.Namespace) -> int:
    print("backtest (stub)")
    return 0


def _cmd_paper(_args: argparse.Namespace) -> int:
    print("paper trading (stub)")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="tradex")
    sub = parser.add_subparsers(dest="command")

    p_ver = sub.add_parser("version", help="print framework version")
    p_ver.set_defaults(func=_cmd_version)

    p_replay = sub.add_parser("replay", help="replay historical data")
    p_replay.set_defaults(func=_cmd_replay)

    p_bt = sub.add_parser("backtest", help="run backtest")
    p_bt.set_defaults(func=_cmd_backtest)

    p_paper = sub.add_parser("paper", help="paper trading session")
    p_paper.set_defaults(func=_cmd_paper)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)
    if not getattr(args, "command", None):
        parser.print_help()
        return 0
    func = getattr(args, "func", None)
    if func is None:
        parser.print_help()
        return 0
    return int(func(args))


if __name__ == "__main__":
    sys.exit(main())
